Version: 2.9.9.RELEASE
Build Date: 20150302224534

* Adds asynchronous logging