Version: 2.9.9.RELEASE
Build Date: 20150302224534

* Disable SSLv2 for APR/native (APR) connector by setting SSLProtocol to TLSv1
