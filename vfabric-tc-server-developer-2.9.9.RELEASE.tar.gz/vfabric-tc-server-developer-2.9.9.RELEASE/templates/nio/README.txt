Version: 2.9.9.RELEASE
Build Date: 20150302224534

* Adds a Non-Blocking IO (NIO) connector for HTTP