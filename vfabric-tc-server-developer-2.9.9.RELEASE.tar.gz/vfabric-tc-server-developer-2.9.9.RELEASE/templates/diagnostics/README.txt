Version: 2.9.9.RELEASE
Build Date: 20150302224534

* Adds a JDBC resource that integrates with request diagnostics to report slow queries
* Adds a ThreadDiagnosticsValve at the Engine level to report slow running requests