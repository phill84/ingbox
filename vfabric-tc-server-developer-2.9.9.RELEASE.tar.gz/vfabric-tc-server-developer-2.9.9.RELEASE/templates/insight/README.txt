Version: 1.9.2.SR6
Build Date: 20141113110441

* Adds Spring Insight Developer Edition
       * Insight Dashboard accessible at /insight
       * Standard collection plugins

* Sets Xmx to 1024M
* Sets MaxPermGen to 256M for Hotspot VMs
* Sets java.awt.headless to true
* Sets javaagent to insight-weaver-1.9.2.SR6.jar